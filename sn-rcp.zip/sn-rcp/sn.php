﻿<?php
/**
	Plugin Name: درگاه پرداخت پرداخت آنلاین برای افزونه اشتراک طلایی
	Version: 1.0
	Description: درگاه پرداخت  پرداخت آنلاین برای افزونه اشتراک طلایی
	Plugin URI: http://
	Author: 
	Author URI: http://
	License: GPL 2
 **/

if (!defined('ABSPATH')) exit;
if( !defined( 'SAMAN_SESSION_COOKIE' ) ) define( 'SAMAN_SESSION_COOKIE', '_PCHELPER_session' );

if ( !class_exists( 'Recursive_ArrayAccess' ) ) {
	class Recursive_ArrayAccess implements ArrayAccess {
		protected $container = array();
		protected $dirty = false;
		protected function __construct( $data = array() ) {
			foreach ( $data as $key => $value ) {
				$this[ $key ] = $value;
			}
		}
		public function __clone() {
			foreach ( $this->container as $key => $value ) {
				if ( $value instanceof self ) {
					$this[ $key ] = clone $value;
				}
			}
		}
		public function toArray() {
			$data = $this->container;
			foreach ( $data as $key => $value ) {
				if ( $value instanceof self ) {
					$data[ $key ] = $value->toArray();
				}
			}
			return $data;
		}
		public function offsetExists( $offset ) {
			return isset( $this->container[ $offset ]) ;
		}
		public function offsetGet( $offset ) {
			return isset( $this->container[ $offset ] ) ? $this->container[ $offset ] : null;
		}
		public function offsetSet( $offset, $data ) {
			if ( is_array( $data ) ) {
				$data = new self( $data );
			}
			if ( $offset === null ) { 
				$this->container[] = $data;
			}
			else {
				$this->container[ $offset ] = $data;
			}
			$this->dirty = true;
		}
		public function offsetUnset( $offset ) {
			unset( $this->container[ $offset ] );
			$this->dirty = true;
		}
	}
}
if ( !class_exists( 'SAMAN_Session' ) ) {
	final class SAMAN_Session extends Recursive_ArrayAccess implements Iterator, Countable {
		protected $session_id;
		protected $expires;
		protected $exp_variant;
		private static $instance = false;
		public static function get_instance() {
			if ( !self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
		protected function __construct() {
			if ( isset( $_COOKIE[SAMAN_SESSION_COOKIE] ) ) {
				$cookie = stripslashes( $_COOKIE[SAMAN_SESSION_COOKIE] );
				$cookie_crumbs = explode( '||', $cookie );
				$this->session_id = $cookie_crumbs[0];
				$this->expires = $cookie_crumbs[1];
				$this->exp_variant = $cookie_crumbs[2];
				if ( time() > $this->exp_variant ) {
					$this->set_expiration();
					delete_option( "_PCHELPER_session_expires_{$this->session_id}" );
					add_option( "_PCHELPER_session_expires_{$this->session_id}", $this->expires, '', 'no' );
				}
			} 
			else {
				$this->session_id = $this->generate_id();
				$this->set_expiration();
			}
			$this->read_data();
			$this->set_cookie();
		}
		protected function set_expiration() {
			$this->exp_variant = time() + (int) apply_filters( 'PCHELPER_session_expiration_variant', 24 * 60 );
			$this->expires = time() + (int) apply_filters( 'PCHELPER_session_expiration', 30 * 60 );
		}
		protected function set_cookie(){
			if( !headers_sent() )
				setcookie(SAMAN_SESSION_COOKIE,$this->session_id.'||'.$this->expires.'||'.$this->exp_variant,$this->expires,COOKIEPATH,COOKIE_DOMAIN );
		}
		protected function generate_id() {
			require_once( ABSPATH . 'wp-includes/class-phpass.php');
			$hasher = new PasswordHash( 8, false );
			return md5( $hasher->get_random_bytes( 32 ) );
		}
		protected function read_data() {
			$this->container = get_option( "_PCHELPER_session_{$this->session_id}", array() );
			return $this->container;
		}
		public function write_data() {
			$option_key = "_PCHELPER_session_{$this->session_id}";
			if ( $this->dirty ) {
				if ( false === get_option( $option_key ) ) {
					add_option( "_PCHELPER_session_{$this->session_id}", $this->container, '', 'no' );
					add_option( "_PCHELPER_session_expires_{$this->session_id}", $this->expires, '', 'no' );
				} 
				else {
					delete_option( "_PCHELPER_session_{$this->session_id}" );
					add_option( "_PCHELPER_session_{$this->session_id}", $this->container, '', 'no' );
				}
			}
		}
		public function json_out() {
			return json_encode( $this->container );
		}
		public function json_in( $data ) {
			$array = json_decode( $data );
			if ( is_array( $array ) ) {
				$this->container = $array;
				return true;
			}
			return false;
		}
		public function regenerate_id( $delete_old = false ) {
			if ( $delete_old ) {
				delete_option( "_PCHELPER_session_{$this->session_id}" );
			}
			$this->session_id = $this->generate_id();
			$this->set_cookie();
		}
		public function session_started() {
			return !!self::$instance;
		}
		public function cache_expiration() {
			return $this->expires;
		}
		public function reset() {
			$this->container = array();
		}
		public function current() {
			return current( $this->container );
		}
		public function key() {
			return key( $this->container );
		}
		public function next() {
			next( $this->container );
		}
		public function rewind() {
			reset( $this->container );
		}
		public function valid() {
			return $this->offsetExists( $this->key() );
		}
		public function count() {
			return count( $this->container );
		}
	}
	function PCHELPER_session_cache_expire() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->cache_expiration();
	}
	function PCHELPER_session_commit() {
		PCHELPER_session_write_close();
	}
	function PCHELPER_session_decode( $data ) {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->json_in( $data );
	}
	function PCHELPER_session_encode() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->json_out();
	}
	function PCHELPER_session_regenerate_id( $delete_old_session = false ) {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->regenerate_id( $delete_old_session );
		return true;
	}
	function PCHELPER_session_start() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		do_action( 'PCHELPER_session_start' );
		return $PCHELPER_session->session_started();
	}
	add_action( 'plugins_loaded', 'PCHELPER_session_start' );
	function PCHELPER_session_status() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		if ( $PCHELPER_session->session_started() ) {
			return PHP_SESSION_ACTIVE;
		}
		return PHP_SESSION_NONE;
	}
	function PCHELPER_session_unset() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->reset();
	}
	function PCHELPER_session_write_close() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->write_data();
		do_action( 'PCHELPER_session_commit' );
	}
	add_action( 'shutdown', 'PCHELPER_session_write_close' );
	function PCHELPER_session_cleanup() {
		global $wpdb;
		if ( defined( 'SAMAN_SETUP_CONFIG' ) ) {
			return;
		}
		if ( ! defined( 'SAMAN_INSTALLING' ) ) {
			$expiration_keys = $wpdb->get_results( "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE '_PCHELPER_session_expires_%'" );
			$now = time();
			$expired_sessions = array();
			foreach( $expiration_keys as $expiration ) {
				if ( $now > intval( $expiration->option_value ) ) {
					$session_id = substr( $expiration->option_name, 20 );
					$expired_sessions[] = $expiration->option_name;
					$expired_sessions[] = "_PCHELPER_session_$session_id";
				}
			}
			if ( ! empty( $expired_sessions ) ) {
				$option_names = implode( "','", $expired_sessions );
				$wpdb->query( "DELETE FROM $wpdb->options WHERE option_name IN ('$option_names')" );
			}
		}
		do_action( 'PCHELPER_session_cleanup' );
	}
	add_action( 'PCHELPER_session_garbage_collection', 'PCHELPER_session_cleanup' );
	function PCHELPER_session_register_garbage_collection() {
		if ( !wp_next_scheduled( 'PCHELPER_session_garbage_collection' ) ) {
			wp_schedule_event( time(), 'hourly', 'PCHELPER_session_garbage_collection' );
		}
	}
	add_action( 'wp', 'PCHELPER_session_register_garbage_collection' );
}

if (!class_exists('RCP_sn') )
{
	class RCP_sn
	{
		public function __construct()
		{
			add_action('init', array($this, 'sn_Verify'));
			add_action('rcp_payments_settings', array($this, 'sn_Setting'));
			add_action('rcp_gateway_sn', array($this, 'sn_Request'));
			add_filter('rcp_payment_gateways', array($this, 'sn_Register'));
			if ( !function_exists('RCP_IRAN_Currencies_By_PCHELPER') && !function_exists('RCP_IRAN_Currencies') )
				add_filter('rcp_currencies', array($this, 'RCP_IRAN_Currencies'));
		}

		public function RCP_IRAN_Currencies( $currencies ) {
			unset($currencies['RIAL']);
			$currencies['ریال'] = __('ریال', 'rcp_sn');
			return $currencies;
		}
				
		public function sn_Register($gateways) {
			global $rcp_options;
			
			if( version_compare( RCP_PLUGIN_VERSION, '2.1.0', '<' ) ) {
				$gateways['sn'] = isset($rcp_options['sn_name']) ? $rcp_options['sn_name'] : __( 'پرداخت آنلاین', 'rcp_sn');
			}
			else {
				$gateways['sn'] = array(
					'label' => isset($rcp_options['sn_name']) ? $rcp_options['sn_name'] : __( 'پرداخت آنلاین', 'rcp_sn'),
					'admin_label' => isset($rcp_options['sn_name']) ? $rcp_options['sn_name'] : __( 'پرداخت آنلاین', 'rcp_sn'),
				);
			}
			return $gateways;
		}

		public function sn_Setting($rcp_options) {
		echo '	
			<hr/>
			<table class="form-table">'; ?>
				<?php do_action( 'RCP_sn_before_settings', $rcp_options ); ?>
				<?php echo '<tr valign="top">
					<th colspan=2><h3>'; ?> <?php _e( 'تنظیمات درگاه پرداخت آنلاین', 'rcp_sn' ); ?><?php echo '</h3></th>
				</tr>
				<tr valign="top">
					<th>
						<label for="rcp_settings[merchant]">'; ?><?php _e( 'مرچنت درگاه پرداخت آنلاین', 'rcp_sn' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[merchant]" style="width: 300px;" name="rcp_settings[merchant]" value="'; ?><?php if( isset( $rcp_options['merchant'] ) ) { echo $rcp_options['merchant']; } ?><?php echo '"/>
					</td>
				</tr>					
				<tr valign="top">
					<th>
						<label for="rcp_settings[sn_query_name]">'; ?><?php _e( 'نام لاتین درگاه', 'rcp_sn' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[sn_query_name]" style="width: 300px;" name="rcp_settings[sn_query_name]" value="'; ?><?php echo isset($rcp_options['sn_query_name']) ? $rcp_options['sn_query_name'] : 'sn'; ?><?php echo '"/>
						<div class="description">'; ?><?php _e( 'این نام در هنگام بازگشت از بانک در آدرس بازگشت از بانک نمایان خواهد شد . از به کاربردن حروف زائد و فاصله جدا خودداری نمایید .', 'rcp_sn' ); ?><?php echo '</div>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="rcp_settings[sn_name]">'; ?><?php _e( 'نام نمایشی درگاه', 'rcp_sn' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[sn_name]" style="width: 300px;" name="rcp_settings[sn_name]" value="'; ?><?php echo isset($rcp_options['sn_name']) ? $rcp_options['sn_name'] : __( 'پرداخت آنلاین', 'rcp_sn'); ?><?php echo '"/>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label>'; ?><?php _e( 'تذکر ', 'rcp_sn' ); ?><?php echo '</label>
					</th>
					<td>
						<div class="description">'; ?><?php _e( 'از سربرگ مربوط به ثبت نام در تنظیمات افزونه حتما یک برگه برای بازگشت از بانک انتخاب نمایید . ترجیحا نامک برگه را لاتین قرار دهید .<br/> نیازی به قرار دادن شورت کد خاصی در برگه نیست و میتواند برگه ی خالی باشد .', 'rcp_sn' ); ?><?php echo '</div>
					</td>
				</tr>'; ?>
				<?php do_action( 'RCP_sn_after_settings', $rcp_options ); ?>
			<?php echo '</table>';
		}
		
		public function sn_Request($subscription_data) {
			
			global $rcp_options;
			ob_start();
			$query = isset($rcp_options['sn_query_name']) ? $rcp_options['sn_query_name'] : 'sn';
			$amount = str_replace( ',', '', $subscription_data['price']);

			
			
			
			
			//Action For sn or RCP Developers...
			do_action( 'RCP_Before_Sending_to_sn', $subscription_data );	
		
			if ($rcp_options['currency'] == 'ریال' || $rcp_options['currency'] == 'IRR' || $rcp_options['currency'] == 'RIAL' || $rcp_options['currency'] == 'ریال ایران' || $rcp_options['currency'] == 'Iranian Rial (&#65020;)')
				$amount = $amount/10;
			
			//Start of sn
						// Security
						@session_start();
						$sec = uniqid();
						$md = md5($sec.'vm');
						// Security
			$Price = intval($amount);
         $ReturnPath = add_query_arg('gateway', $query, $subscription_data['return_url']);
			$ResNumber = $subscription_data['key'];
			$Paymenter = $subscription_data['user_name'];
			$Email = $subscription_data['user_email'];
			$Description = sprintf(__('خرید اشتراک %s برای کاربر %s', 'rcp_sn'), $subscription_data['subscription_name'],$subscription_data['user_name']);
			$Mobile = '-';			
			//Filter For sn or RCP Developers...
			$Description = apply_filters( 'RCP_sn_Description', $Description, $subscription_data );
			$Mobile = apply_filters( 'RCP_Mobile', $Mobile, $subscription_data );

			$resnum = time();
									$data_string = json_encode(array(
									'pin'=> $rcp_options['merchant'],
									'price'=> $amount,
									'callback'=> $ReturnPath.'&md='.$md.'&sec='.$sec ,
									'order_id'=> $resnum,
									'ip'=> $_SERVER['REMOTE_ADDR'],
									'callback_type'=>2
									));

									$ch = curl_init('https://developerapi.net/api/v1/request');
									curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($ch, CURLOPT_HTTPHEADER, array(
									'Content-Type: application/json',
									'Content-Length: ' . strlen($data_string))
									);
									curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
									curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
									$result = curl_exec($ch);
									curl_close($ch);


									$json = json_decode($result,true);
									if(!empty($json['result']) AND $json['result'] == 1)
									{
			$au=$json['au'];
			$sn_payment_data = array(
				'user_id'             => $subscription_data['user_id'],
				'subscription_name'     => $subscription_data['subscription_name'],
				'subscription_key'	 => $subscription_data['key'],
				'amount'           => $amount,
				'order_id'           => $resnum,
				'au'           => $au,
			);			
			$PCHELPER_session = SAMAN_Session::get_instance();
			@session_start();
			$PCHELPER_session['sn_payment_data'] = $sn_payment_data;
			$_SESSION["sn_payment_data"] = $sn_payment_data;	
			// Set Session
$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=>$invoice_id ,
	'au'=>$json['au'] ,
];

				 echo ('<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>');
			}
			else
			{
				wp_die( sprintf(__('متاسفانه پرداخت به دلیل خطای زیر امکان پذیر نمی باشد . <br/><b> %s </b>', 'rcp_sn'), $json['msg']) );
			}
			//End of sn
				
			exit;
		}
		
		public function sn_Verify() {
			
			if (!isset($_GET['gateway']))
				return;
			
			if ( !class_exists('RCP_Payments') )
				return;
			
			global $rcp_options, $wpdb, $rcp_payments_db_name;
			@session_start();
			$PCHELPER_session = SAMAN_Session::get_instance();
			if (isset($PCHELPER_session['sn_payment_data']))
				$sn_payment_data = $PCHELPER_session['sn_payment_data'];
			else 
				$sn_payment_data = isset($_SESSION["sn_payment_data"]) ? $_SESSION["sn_payment_data"] : '';
			
			$query = isset($rcp_options['sn_query_name']) ? $rcp_options['sn_query_name'] : 'sn';
			
			if ($sn_payment_data)
			{
				$user_id 			= $sn_payment_data['user_id'];
				$subscription_name 	= $sn_payment_data['subscription_name'];
				$subscription_key 	= $sn_payment_data['subscription_key'];
				$amount 			= $sn_payment_data['amount'];
				$au 			= $sn_payment_data['au'];
				$order_id 			= $sn_payment_data['order_id'];
				$subscription_id    = rcp_get_subscription_id( $user_id );
				$user_data          = get_userdata( $user_id );
				$payment_method =  isset($rcp_options['sn_name']) ? $rcp_options['sn_name'] : __( 'پرداخت آنلاین', 'rcp_sn');

				$member = new RCP_Member( $user_id );
				$subscription_id = $member->get_pending_subscription_id();
				if( empty( $subscription_id ) ) $subscription_id = $member->get_subscription_id();

				if( ! $user_data || ! $subscription_id || ! rcp_get_subscription_details( $subscription_id ) )
					return;
				$new_payment = 1;
				if( $wpdb->get_results( $wpdb->prepare("SELECT id FROM " . $rcp_payments_db_name . " WHERE `subscription_key`='%s' AND `payment_type`='%s';", $subscription_key, $payment_method ) ) )
					$new_payment = 0;

				unset($GLOBALS['sn_new']);
				$GLOBALS['sn_new'] = $new_payment;
				global $new;
				$new = $new_payment;
				if ($new_payment == 1)
				{

									// Security
				@session_start();
				$sec=$_GET['sec'];
				$mdback = md5($sec.'vm');
				$mdurl=$_GET['md'];
				// Security
					if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl ){
												// CallBack
							$bank_return = $_POST + $_GET ;
							$data_string = json_encode(array (
							'pin' => $rcp_options['merchant'],
							'price' => $amount,
							'order_id' => $order_id,
							'au' => $au,
							'bank_return' =>$bank_return,
							));

							$ch = curl_init('https://developerapi.net/api/v1/verify');
							curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							curl_setopt($ch, CURLOPT_HTTPHEADER, array(
							'Content-Type: application/json',
							'Content-Length: ' . strlen($data_string))
							);
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
							curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
							$result = curl_exec($ch);
							curl_close($ch);
							$json = json_decode($result,true);
					
					if (!empty($json['result'])&&$json['result']==1)
					{
						$payment_status = 'completed';
						$fault = 'completed';
						$transaction_id = $au;
					}
					else
					{
						$payment_status = 'failed';
						$fault = $json['msg'];
						$transaction_id = 0;
					}
						}
					else
					{
						$payment_status = 'failed';
						$fault = $json['msg'];
						$transaction_id = 0;
					}
					unset($GLOBALS['sn_payment_status']);
					unset($GLOBALS['sn_transaction_id']);
					unset($GLOBALS['sn_fault']);
					unset($GLOBALS['sn_subscription_key']);
					$GLOBALS['sn_payment_status'] = $payment_status;
					$GLOBALS['sn_transaction_id'] = $transaction_id;
					$GLOBALS['sn_subscription_key'] = $subscription_key;
					$GLOBALS['sn_fault'] = $fault;
					global $sn_transaction;
					$sn_transaction = array();
					$sn_transaction['sn_payment_status'] = $payment_status;
					$sn_transaction['sn_transaction_id'] = $transaction_id;
					$sn_transaction['sn_subscription_key'] = $subscription_key;
					$sn_transaction['sn_fault'] = $fault;
					if ($payment_status == 'completed') 
					{
				
						$payment_data = array(
							'date'             => date('Y-m-d g:i:s'),
							'subscription'     => $subscription_name,
							'payment_type'     => $payment_method,
							'subscription_key' => $subscription_key,
							'amount'           => $amount,
							'user_id'          => $user_id,
							'transaction_id'   => $transaction_id
						);
					
						//Action For sn or RCP Developers...
						do_action( 'RCP_sn_Insert_Payment', $payment_data, $user_id );
					
						$rcp_payments = new RCP_Payments();
						$rcp_payments->insert( $payment_data );					
					
						rcp_set_status( $user_id, 'active' );
						
						if( version_compare( RCP_PLUGIN_VERSION, '2.1.0', '<' ) ) {
							rcp_email_subscription_status( $user_id, 'active' );
							if( ! isset( $rcp_options['disable_new_user_notices'] ) )
								wp_new_user_notification( $user_id );
						}
						
						
						update_user_meta( $user_id, 'rcp_payment_profile_id', $user_id );
						
						update_user_meta( $user_id, 'rcp_signup_method', 'live' );
						//rcp_recurring is just for paypal or ipn gateway
						update_user_meta( $user_id, 'rcp_recurring', 'no' ); 
					
						$subscription = rcp_get_subscription_details( rcp_get_subscription_id( $user_id ) );
						$member_new_expiration = date( 'Y-m-d H:i:s', strtotime( '+' . $subscription->duration . ' ' . $subscription->duration_unit . ' 23:59:59' ) );
						rcp_set_expiration_date( $user_id, $member_new_expiration );	
						delete_user_meta( $user_id, '_rcp_expired_email_sent' );
									
						$log_data = array(
							'post_title'    => __( 'تایید پرداخت', 'rcp_sn' ),
							'post_content'  =>  __( 'پرداخت با موفقیت انجام شد . کد تراکنش : ', 'rcp_sn' ).$transaction_id.__( ' .  روش پرداخت : ', 'rcp_sn' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );

						//Action For sn or RCP Developers...
						do_action( 'RCP_sn_Completed', $user_id );				
					}	

					
					
					if ($payment_status == 'cancelled')
					{
					
						$log_data = array(
							'post_title'    => __( 'انصراف از پرداخت', 'rcp_sn' ),
							'post_content'  =>  __( 'تراکنش به دلیل انصراف کاربر از پرداخت ، ناتمام باقی ماند .', 'rcp_sn' ).__( ' روش پرداخت : ', 'rcp_sn' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );
					
						//Action For sn or RCP Developers...
						do_action( 'RCP_sn_Cancelled', $user_id );	

					}	
					
					if ($payment_status == 'failed') 
					{
									
						$log_data = array(
							'post_title'    => __( 'خطا در پرداخت', 'rcp_sn' ),
							'post_content'  =>  __( 'تراکنش به دلیل خطای رو به رو ناموفق باقی ماند :', 'rcp_sn' ).$this->Fault_Get($fault).__( ' روش پرداخت : ', 'rcp_sn' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );
					
						//Action For sn or RCP Developers...
						do_action( 'RCP_sn_Failed', $user_id );	
					
					}
			
				}
				add_filter( 'the_content', array($this,  'sn_Content_After_Return') );
			}
		}
		 
		
		public function sn_Content_After_Return( $content ) { 
			
			global $sn_transaction, $new;
			
			$PCHELPER_session = SAMAN_Session::get_instance();
			@session_start();
			
			$new_payment = isset($GLOBALS['sn_new']) ? $GLOBALS['sn_new'] : $new;
			
			$payment_status = isset($GLOBALS['sn_payment_status']) ? $GLOBALS['sn_payment_status'] : $sn_transaction['sn_payment_status'];
			$transaction_id = isset($GLOBALS['sn_transaction_id']) ? $GLOBALS['sn_transaction_id'] : $sn_transaction['sn_transaction_id'];
			$fault = isset($GLOBALS['sn_fault']) ? $this->Fault_Get($GLOBALS['sn_fault']) : $this->Fault_Get($sn_transaction['sn_fault']);
			
			if ($new_payment == 1) 
			{
			
				$sn_data = array(
					'payment_status'             => $payment_status,
					'transaction_id'     => $transaction_id,
					'fault'     => $fault
				);
				
				$PCHELPER_session['sn_data'] = $sn_data;
				$_SESSION["sn_data"] = $sn_data;	
			
			}
			else
			{
				if (isset($PCHELPER_session['sn_data']))
					$sn_payment_data = $PCHELPER_session['sn_data'];
				else 
					$sn_payment_data = isset($_SESSION["sn_data"]) ? $_SESSION["sn_data"] : '';
			
				$payment_status = isset($sn_payment_data['payment_status']) ? $sn_payment_data['payment_status'] : '';
				$transaction_id = isset($sn_payment_data['transaction_id']) ? $sn_payment_data['transaction_id'] : '';
				$fault = isset($sn_payment_data['fault']) ? $this->Fault($sn_payment_data['fault']) : '';
			}
			
			$message = '';
			
			if ($payment_status == 'completed') {
				$message = '<br/>'.__( 'پرداخت با موفقیت انجام شد . کد تراکنش : ', 'rcp_sn' ).$transaction_id.'<br/>';
			}
			
			if ($payment_status == 'cancelled') {
				$message = '<br/>'.__( 'تراکنش به دلیل انصراف شما نا تمام باقی ماند .', 'rcp_sn' );
			}
			
			if ($payment_status == 'failed') {
				$message = '<br/>'.__( 'تراکنش به دلیل خطای زیر ناموفق باقی ماند :', 'rcp_sn' ).'<br/>'.$fault.'<br/>';
			}
			
			return $content.$message;
		}
		
		private static function Fault_Send($error) {
			$message = " ";
			switch($error)
			{
				case "-1" :
					$message = "merchant ارسالی تعریف نشده است";
				break;
				case "-2" :
					$message = "مبلغ تراکنش کمتر از 1000 ریال است";
				break;
				case "-3" :
					$message = "مسیر برگشت وجود ندارد";
				break;
										
				case "-4" :
					$message = "درگاه تعریف نشده است";
				break;	
			}
			return $message;
		}
		private static function Fault_Get($error)
		{
			return $error;
		}
		
	}
}
new RCP_sn();

if ( !function_exists('change_cancelled_to_pending_By_PCHELPER'))
{
	add_action( 'rcp_set_status', 'change_cancelled_to_pending_By_PCHELPER', 10, 2 );
	function change_cancelled_to_pending_By_PCHELPER( $status, $user_id )
	{
		if( 'cancelled' == $status )
			rcp_set_status( $user_id, 'expired' );
		return true;
	}
}

?>